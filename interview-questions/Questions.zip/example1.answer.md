1. Start of main thread
3. Inside Promise executor
4. Promise resolved
2. Inside setTimeout callback

Read: 
Event loop, stack queue, call stack, micro task queue

